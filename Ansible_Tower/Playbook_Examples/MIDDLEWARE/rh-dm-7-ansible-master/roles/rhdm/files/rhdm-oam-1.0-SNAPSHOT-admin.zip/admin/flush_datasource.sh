#!/bin/bash
#
# ============================================================
# Red Hat Consulting EMEA, 2018
#
# GroupId-------: com.redhat.emea.es.bcn.sso.oam
# ArtifactId----: rh-sso-oam
# Version-------: 1.0-SNAPSHOT
# Created-------: 20180503-21:27:22
# ============================================================
# Description---: Flush DataSource
# ============================================================
#
# chmod 774 *.sh
#
#
# EOH
function usage(){
    echo "Usage: $0 -d <datasourName> -m <flush mode>"
    echo "Ex: $0 -d ExampleDS -m idle"
    echo "Mode allowed: [idle | inv | grace]:"
    echo " -idle-: flush-idle-connection-in-pool()"
    echo " -inv--: flush-invalid-connection-in-pool()"
    echo " -grace: flush-gracefully-connection-in-pool()"
    exit 1
}

V_ADMIN_DIR=`dirname $0`
source ${V_ADMIN_DIR}/functions.sh

# Load variables environment
. $V_ADMIN_DIR/setEnv.sh


# Step 1 - Parser Input Parameters
while [ $# -gt 0 ]
do
    case $1 in
       -d| --datasource )    shift
                             DS_NAME="$1"
                             ;;
       -m| --modeflush )     shift
                             FLUSH_MODE="$1"
                             ;;
        -h | --help )        usage
                             exit
                             ;;
        * )                  usage
                             exit 1
    esac
    shift
done

if [ -z "$FLUSH_MODE" ];then
    warn "The '--modeflush' or '-m' parameter is mandatory. We are going to use: 'flush-idle-connection-in-pool'"
    FLUSH_OPERATION="flush-idle-connection-in-pool()"
fi

if [ -z  "$DS_NAME" ];then
    DS_NAME="KeycloakDS"
fi

case ${FLUSH_MODE} in
   idle )     FLUSH_OPERATION="flush-idle-connection-in-pool()"
              ;;
   inv )      FLUSH_OPERATION="flush-invalid-connection-in-pool()"
              ;;
   grace)     FLUSH_OPERATION="flush-gracefully-connection-in-pool()"
              ;;
   * )        echo "Unkown operation: [${FLUSH_MODE}]"
              usage
              ;;
esac

msg "Using the ${FLUS_OPERATION}' operation for the ${DS_NAME} datasource"

FLUSH_COMMAND="/subsystem=datasources/data-source=${DS_NAME}:${FLUSH_OPERATION}"

msg ${JBOSS_BIN}/jboss-cli.sh --connect --command="${FLUSH_COMMAND}"
${JBOSS_BIN}/jboss-cli.sh --connect --command="${FLUSH_COMMAND}"


exit 1
#
# EOF