#!/bin/bash
#
# ============================================================
# Red Hat Consulting EMEA, 2018
#
# GroupId-------: com.redhat.emea.es.bcn.sso.oam
# ArtifactId----: rh-sso-oam
# Version-------: 1.0-SNAPSHOT
# Created-------: 20180503-21:27:22
# ============================================================
# Description--: Utility to create class histogram
#
# soruce: https://docs.oracle.com/javase/8/docs/technotes/guides/troubleshoot/tooldescr006.html#BABEJDGE
# source: https://docs.oracle.com/javase/8/docs/technotes/tools/unix/java.html
# -XX:+PrintClassHistogram
#   Enables printing of a class instance histogram after a Control+C event (SIGTERM).
#   By default, this option is disabled.
#   Setting this option is equivalent to running the "jmap -histo command",
#   or the "jcmd pid GC.class_histogram" command,
#   where pid is the current Java process identifier.
#
# ============================================================
#
# ============================================================
# Pre Steps---:
# chmod 774 *.sh
# ============================================================
#
#
#
# EOH
function usage(){
    echo "Usage: $0 -p <PID> [-o <path_outfile> ]"
    echo "Ex: $0 -p 5555 -o /home/user01"
    exit 1
}
# Step 1 - Set Admin DIR:
V_ADMIN_DIR=$(dirname $0)

source ${V_ADMIN_DIR}/functions.sh

# Step 2 - Save original arguments
V_INPUT_PARAM=$*
PREFIX_LOG="[ $0 ]"

# Step 3 - Parser Input Parameters
while [ $# -gt 0 ]
do
    case $1 in
        -p | --pid  )   shift
                        pid=$1
                        ;;
        -o | --out )    shift
                        out=$1
                        ;;
        -h | --help )   usage
                        exit
                        ;;
        * )             usage
                        exit 1
    esac
    shift
done

# Step 4 - Check PID exists
if [ -z $pid ];then
  #
  PID=`ps aux | grep java | grep "D\[Standalone]" | awk '{ print $2; }'`
  if [ "$PID" ]
  then
    msg "We will use the <pid> JBoss Standalone Instance"
    pid=$PID
  else
    err "The <pid> is necessary for to continue: -l <pid>"
    exit 1
  fi
fi

# Step 5 - Check Outpath exists
if [[ -z $out || ! -d $out ]];then
    msg "The $out path doesn't exist. Default: /tmp"
    out="/tmp"
fi

_jcmd=""
# Step 6 - Check jcmd is right
result=$(type -p jcmd)
if [[ -n "$result" ]];then
    _jcmd=jcmd
elif [[-n "$JAVA_HOME" ]] && [[-x "$JAVA_HOME/bin/jcmd" ]];then
    _jcmd="$JAVA_HOME/bin/jcmd"
else
    err "jcmd no exists"
    exit 1
fi

# Step 7 - Create Heap Histogram
HH_file=${out}/HH_${pid}_$(date_dump).hprof
msg "${_jcmd} $pid GC.class_histogram > ${HH_file}"
${_jcmd} ${pid} GC.class_histogram > ${HH_file}
if [ $? -ne 0 ]
then
    err "The operation has not completed correctly"
    exit 1
else
    msg "The Heap Dump file created: ${HH_file}"
fi

exit 0
#
# EOF