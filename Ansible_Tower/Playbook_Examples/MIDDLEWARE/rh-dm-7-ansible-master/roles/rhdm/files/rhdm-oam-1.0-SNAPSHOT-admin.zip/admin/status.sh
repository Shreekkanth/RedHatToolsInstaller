#!/bin/bash
#
# ============================================================
# Red Hat Consulting EMEA, 2018
#
# GroupId-------: com.redhat.emea.es.bcn.sso.oam
# ArtifactId----: rh-sso-oam
# Version-------: 1.0-SNAPSHOT
# Created-------: 20180503-21:27:22
# ============================================================
# Description---: Status JBoss service
# ============================================================
#
# chmod 774 *.sh
#
#
# EOH

V_ADMIN_DIR=`dirname $0`
source ${V_ADMIN_DIR}/functions.sh

# Load variables environment
. $V_ADMIN_DIR/setEnv.sh

systemctl status ${SSO_SERVICE_NAME}

exit 0

# EOF