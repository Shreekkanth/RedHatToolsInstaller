#!/bin/bash
#
# ============================================================
# Red Hat Consulting EMEA, 2018
#
# GroupId-------: com.redhat.emea.es.bcn.sso.oam
# ArtifactId----: rh-sso-oam
# Version-------: 1.0-SNAPSHOT
# Created-------: 20180503-21:27:22
# ============================================================
# Description---: Start JBoss service
# ============================================================
#
# chmod 774 *.sh
#
#
# EOH
function usage(){
    echo "Usage: $0 -d <datasourName>"
    echo "Ex: $0 -d ExampleDS"
    exit 1
}

V_ADMIN_DIR=`dirname $0`
source ${V_ADMIN_DIR}/functions.sh

# Load variables environment
. $V_ADMIN_DIR/setEnv.sh

# Step 1 - Parser Input Parameters
while [ $# -gt 0 ]
do
    case $1 in
       -d | --datasource )     shift
                               DS_NAME="$1"
                                ;;
        -h | --help )           usage
                                exit
                                ;;
        * )                     usage
                                exit 1
    esac
    shift
done

if [ -z "$DS_NAME" ];then
    DS_NAME="KeycloakDS"
fi


msg "${JBOSS_BIN}/jboss-cli.sh --connect --file=${V_ADMIN_DIR}/cli/check_datasources.cli -DdsName=${DS_NAME}"
${JBOSS_BIN}/jboss-cli.sh --connect --file=${V_ADMIN_DIR}/cli/check_datasources.cli -DdsName=${DS_NAME}


exit 1
#
# EOF