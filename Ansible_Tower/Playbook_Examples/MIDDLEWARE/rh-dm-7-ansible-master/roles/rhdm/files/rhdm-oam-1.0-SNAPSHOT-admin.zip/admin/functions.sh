#!/bin/bash
#
# ============================================================
# Red Hat Consulting EMEA, 2018
#
# GroupId-------: com.redhat.emea.es.bcn.sso.oam
# ArtifactId----: rh-sso-oam
# Version-------: 1.0-SNAPSHOT
# Created-------: 20180503-21:27:22
# ============================================================
# Description--: functions
# ============================================================
#
# chmod 774 *.sh
#
#
#### LOG VERBOSITY
# 0 - NONE--: No registra ningun mensaje
# 1 - ERROR-: Registra solo mensajes de error
# 2 - WARN--: Registra mensajes de alerta
# 3 - INFO--: Registra solo mensajes de error y informativos
# 4 - DEBUG-: Registra mensajes de error, informativos y de debug
#
# EOH
# Default 3
LOG_LEVEL=3
SCREEN_ONLY=""

# colors
# Black       0;30     Dark Gray     1;30
# Blue        0;34     Light Blue    1;34
# Green       0;32     Light Green   1;32
# Cyan        0;36     Light Cyan    1;36
# Red         0;31     Light Red     1;31
# Purple      0;35     Light Purple  1;35
# Brown       0;33     Yellow        1;33
# Light Gray  0;37     White         1;37

red='\e[0;31m'
blue='\e[0;34m'
green='\e[0;32m'
brown='\e[0;33m'
reset='\e[0m'
bold='\e[1m'
#
col_dbg='\e[0;34m'
col_msg='\e[0;32m'
col_warn='\e[0;33m'
col_err='\e[0;31m'

LINE_PADDING=''
CHAR_CAPTION="."
LINE_PAD_LENGTH=70
for ((i=0; i<$LINE_PAD_LENGTH; i++)); do
    LINE_PADDING+=$CHAR_CAPTION
done
LINE_PADDING+=":"


function date_logf() {
    #date "+%a %d %b %Y %T"
    date "+[%F %T]"
}

function date_gc() {
    date "+%F"
}

function date_dump() {
    date "+%F_%H-%M-%S"
}

function _log(){
    if [ $LOG_LEVEL -gt $1 ]
    then
        printf "%b%s %s %s: %s %s ${bold}%s${reset}\n" $6 "$(date_logf)" "$2" "$3" "$4" "${LINE_PADDING:${#2} + ${#4} + ${#3} + 2}" "$5"
    fi
}

function err() {
    _log 0 "[ERROR]" "$PREFIX_LOG" "$1" "[KO]" ${col_err}
}

function warn() {
    _log 1 "[WARN]" "$PREFIX_LOG" "$1" "[OK?]" ${col_warn}
}

function msg() {
    _log 2 "[INFO]" "$PREFIX_LOG" "$1" "[OK]" ${col_msg}
}

function dbg() {
    _log 3 "[DEBUG]" "$PREFIX_LOG" "$1" "[--]" ${col_dbg}
}


#
# EOF
