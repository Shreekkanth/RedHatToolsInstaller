#!/bin/bash
#
# ============================================================
# Red Hat Consulting EMEA, 2018
#
# GroupId-------: com.redhat.emea.es.bcn.sso.oam
# ArtifactId----: rh-sso-oam
# Version-------: 1.0-SNAPSHOT
# Created-------: 20180503-21:27:22
# ============================================================
# Description--: Utility to create thread dump
# ============================================================
#
# ============================================================
# Pre Steps---:
# chmod 774 *.sh
# ============================================================
#
#
# EOH
function usage(){
    echo "Usage: $0 -l <PID> [-o <path_outfile> ]"
    echo "Usage: $0 -F -l <PID> [-o <path_outfile> ]"
    echo "Ex: $0 -l 5555 -o /home/user01"
    echo "Ex: $0 -F -l 5555 -o /home/user01"
    exit 1
}
# Step 1 - Set Admin DIR:
V_ADMIN_DIR=$(dirname $0)

source ${V_ADMIN_DIR}/functions.sh

# Step 2 - Save original arguments
V_INPUT_PARAM=$*
PREFIX_LOG="[ $0 ]"

# Step 3 - Parser Input Parameters
while [ $# -gt 0 ]
do
    case $1 in
        -l | --pid )    shift
                        pid=$1
                        ;;
        -o | --out )    shift
                        out=$1
                        ;;
        -F )            F="-F"
                        ;;
        -h | --help )   usage
                        exit
                        ;;
        * )             usage
                        exit 1
    esac
    shift
done

# Step 4 - Check PID exists
if [ -z $pid ];then
  #
  PID=`ps aux | grep java | grep "D\[Standalone]" | awk '{ print $2; }'`
  if [ "$PID" ]
  then
    msg "We will use the <pid> JBoss Standalone Instance"
    pid=$PID
  else
    msg "The <pid> is necessary for to continue: -l <pid>"
    exit 1
  fi
fi

# Step 5 - Check Outpath exists
if [[ -z $out || ! -d $out ]];then
    msg "The $out path doesn't exist. Default: /tmp"
    out="/tmp"
fi

_jstack=""
# Step 6 - Check jstack is right
result=$(type -p jstack)
if [[ -n "$result" ]];then
    _jstack=jstack
elif [[-n "$JAVA_HOME" ]] && [[-x "$JAVA_HOME/bin/jstack" ]];then
    _jstack="$JAVA_HOME/bin/jstack"
else
    err "jstack no exists"
    exit 1
fi

# Step 7 - Create Thread Dump
TD_file=${out}/TD_${pid}_$(date_dump).tdump
msg "${_jstack} $F -l $pid >> ${TD_file}"
${_jstack} $F -l $pid >> ${TD_file}
if [ $? -ne 0 ]
then
    err "The operation has not completed correctly"
    exit 1
else
    msg "The Heap Dump file created: ${TD_file}"
fi

exit 0
#
# EOF