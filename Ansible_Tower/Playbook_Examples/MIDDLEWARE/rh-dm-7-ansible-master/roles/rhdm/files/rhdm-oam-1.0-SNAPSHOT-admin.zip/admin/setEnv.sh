#
#
#
JBOSS_HOME=/sso/rh-sso-7.2
JBOSS_BIN=${JBOSS_HOME}/bin
V_HOST=$(hostname -s)
TMP_DIR=/tmp
#
SSO_SERVICE_NAME=sso.service
MYSQL_SERVICE_NAME=mysql_my_cnf_dev.service
#
#
# EOF